import os

__version__ = '0.1'
__license__ = 'Apache'

PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
