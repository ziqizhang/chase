
class FeatureVectorizer:
    def __init__(self):
        pass

    def transform_inputs(self, tweets_original, tweets_cleaned, out_folder, flag):
        pass
